package usa.sesion1.savitest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    Button boton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        getSupportActionBar().setDisplayShowHomeEnabled(true);

        getSupportActionBar().setTitle("SaVi");

        getSupportActionBar().setLogo(R.mipmap.iconosavy);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        boton2 = (Button)  findViewById(R.id.boton2);
        boton2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {


                Toast.makeText(getApplicationContext(),"oprimio boton comprar", Toast.LENGTH_LONG).show();

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuopciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.inicio){
            Toast.makeText(this, "selecciono inicio", Toast.LENGTH_LONG).show();
            Intent mainPantalla = new Intent(this, MainActivity.class);
            startActivity(mainPantalla);
        }
        if (id==R.id.productos){
            Toast.makeText(this, "selecciono productos", Toast.LENGTH_LONG).show();
            Intent segundaPantalla = new Intent(this, MainActivity2.class);
            startActivity(segundaPantalla);
        }
        if (id==R.id.servicios){
            Toast.makeText(this, "selecciono servicios", Toast.LENGTH_LONG).show();
            Intent terceraPantalla = new Intent(this, MainActivity3.class);
            startActivity(terceraPantalla);
        }
        if (id==R.id.sucursales){
            Toast.makeText(this, "selecciono sucursales", Toast.LENGTH_LONG).show();
            Intent cuartaPantalla = new Intent(this, MainActivity4.class);
            startActivity(cuartaPantalla);
        }
        return super.onOptionsItemSelected(item);

    }
}