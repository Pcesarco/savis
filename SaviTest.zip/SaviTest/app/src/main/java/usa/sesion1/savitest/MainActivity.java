package usa.sesion1.savitest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.file.Files;

public class MainActivity extends AppCompatActivity {
    Button boton1;
    TextView texto1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayShowHomeEnabled(true);

        getSupportActionBar().setTitle("SaVi");
        getSupportActionBar().setLogo(R.mipmap.iconosavy);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        boton1 = (Button)  findViewById(R.id.boton1);
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                texto1.setText("SaVi Delicious and Healthy eating");

                Toast.makeText(getApplicationContext(),"oprimio boton inicio", Toast.LENGTH_LONG).show();

            }
        });


        texto1 = (TextView) findViewById(R.id.texto1);




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuopciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.inicio){
            Toast.makeText(this, "selecciono inicio", Toast.LENGTH_LONG).show();
            Intent mainPantalla = new Intent(this, MainActivity.class);
            startActivity(mainPantalla);
        }
        if (id==R.id.productos){
            Toast.makeText(this, "selecciono productos", Toast.LENGTH_LONG).show();
            Intent segundaPantalla = new Intent(this, MainActivity2.class);
            startActivity(segundaPantalla);
        }
        if (id==R.id.servicios){
            Toast.makeText(this, "selecciono servicios", Toast.LENGTH_LONG).show();
            Intent terceraPantalla = new Intent(this, MainActivity3.class);
            startActivity(terceraPantalla);
        }
        if (id==R.id.sucursales){
            Toast.makeText(this, "selecciono sucursales", Toast.LENGTH_LONG).show();
            Intent cuartaPantalla = new Intent(this, MainActivity4.class);
            startActivity(cuartaPantalla);
        }
        return super.onOptionsItemSelected(item);

    }
}